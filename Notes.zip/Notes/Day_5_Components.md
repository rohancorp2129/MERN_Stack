# Components-


😊Is A Building block of React Application - to build SPA

Is Display UI data jsx code i.e small piece of code
Reusable,
Extensible
Separation

Every Component must return some markup (JSX) 

Separate JS File i.e Component


**********************************************************

# Component Based Architecture to build SPA

SPA- Single Page Application- Components Are Intergrated- 

MPA- Multiple page- multiple times reloading

Like SPA- jquery and AJAx- 

**********************************************************


# Types of Components


# 1 Stateless Functional Components- 

Resuable
Simple,easy,
Better to use
Cant extends Component

Stateless- no state
No render method,

# Adv Topic
 hook used


# Syntax


import React from 'react';

const App=()=>{

        return(
                <>


                </>
        )

}


**********************************************************

# module

# Import export

Every JS file is a module and each module need to export for Reusability


😊1 default export
export default App;


😊Multiple named exports- {name}










