
# Steps To Create React APP

        node -v
        npm -v
      

        mkdir React_JS_training
        cd React_JS_training

        mkdir Day_1_React
        cd Day_1_React

        npx create-react-app myapp



# Solution:  



# Error 1

          npx create-react-app myapp

          error ?

          npm cache clean --force
          npm i -g npm

          npx create-react-app myapp

          cd myapp
          npm start


Run on 

Port no 3000
Total Port- 65536


 # Error 2 

         latest version conflict

         web vitals- testing package error


         cd myapp
         npm i web-vitals
         npm start


***********************************************

# Error 3 Powershell Error

Open Powerfull In Search Bar

        Run as administrator

        Get-ExecutionPolicy -List
        Set-ExecutionPolicy RemoteSigned

        
        Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
