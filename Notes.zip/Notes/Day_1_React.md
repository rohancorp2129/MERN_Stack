 
 # What Is React

 
👉JS- library
👉Front end Development

Ghost Problem

2011-  developed- Jordan Walke- data management

ReactJS-

Fb/Meta-

2013- 
publish
open source
free 




*************************************************************

 # Why React JS 

Most Demanding /Popular 

Easy to learn
Need only JS

JSX- extension of JS i.e 

Freedom to code and code is in our control while using library

No limitation
Faster Development

we can use 3rd party libraies- AJAX,Bootstrap,MUI,Routing,Axios,Redux.....

npm i react-Bootstrap
npm i bootstrap@5.2


Easy,Fast Scalable,faster development


JSX- JS XML


*************************************************************************

# Angular - JS FW -Google -2016
          tightly coupled / Highly Coupled - one component depends on another component i.e interconnected each other

# ReactJS - JS Lib - Meta -2011
          loosely coupled-depends on interface rather than class and
          i.e component operate independent and less depenedent on each other 

*******************************************************

# Ajax

We can fetch Ajax request also

Ajax -request- Asyncronous Java Script XML 
   Is not A PL
   Its FW

   -is a XMLHTTPRequest  object to communicate with server
   -we can send and receive any type of data i.e html,xml,json,text data
-  Avoid Reloading of our web page

Performance Increase -SPA

********************************************************

# What is Jquery?

jQuery is a fast, small, and feature-rich JavaScript library. 
It makes things like HTML document traversal and manipulation, event handling, animation, 
and Ajax much simpler with an easy-to-use API that works across a multitude of browsers. 

With a combination of versatility and extensibility, 
jQuery has changed the way that millions of people write JavaScript.


*********************************************************

# Features of React JS

DOM_
document=>html=>head=>title=>"text" and body=>img=>src,height,width=""

👉DOM-   Virtual DOM

👉XSS protection- Cross site protection

👉one way binding( Unidirectional Data flow)-Parent To Child
  no dependency injection (Angular Concept)

👉Single Page Application
  SPA-Imporve Performance and faster result

👉JSX- is Like IS JS - extension of javascript

********************************************
# Summary 

👉JS librray meta-2011 /2013-publish
👉Virtual DOM- React Faster (Copy of regular dom)
👉one way binding-data flow
👉XSS Protection- security
👉SPA-Single Page Application-Performance Improve and fast result 
        i.e Component Based Architecture

👉JSX- extension of JS i.e we can write html and JS code in one file


********************************************
# Tools/ libraries-

👉Testing- Jest 
👉Routing-  React Router
👉Mobile App-  React native
👉State mgmt-  Redux/Mobux

👉Babel - is a Transpiler-JSX-    convert JSX (Modern JS) into plain JS

    Most Popular Tool OF JS
    convert es-6 features into backward compatiable version
    polyfill features


    Array.map(()=>{

    })

    Array.includes()

      let a=20;
      var a=20;


 👉React Developer tool- Development
 👉Redux Developer tool- State Management 

 👉Designing-  Bootstrap  and MUI


      npm i MUI

**************************************************

# React Only Work on View in MVC

👉MVC-  View - popular Designing pattern to create web application
only view 

*******************************************


# Disadvantage-

 👉VD needs more memory
 👉More DOM manipulation
 👉Only Build UI but cant control flow of application i.e View
 👉need 3rd party libraries


 *****************************************


 # Application-  

    FB, Gmail,Web whatasapp,
    Instagram,FB,netflix,Twitter,YT
    outlook,Airbnb
    dropbox,shopify ,trello,Linkedin and More
    Amazon
    flipkart

******************************************************
