



# JSX ? - Extension of JS 


extension of JS or JS XML (write custom tag)
We can write JS and HTML/XML In one File


# JSX Rules 


😊Must have JSX Container=>  

empty container used to wrapped/ grouping the JSX Code

<React.Fragment> </React.Fragment> 
<React.StrictMode> </React.StrictMode>
<> </>




React.Fragment=  Is a container 


*******************************************************

# React.StrictMode 

Is a tool that highlights potential issues in a programme. 
It works by encapsulating a portion of your full application as a component.

StrictMode does not render any visible elements in the DOM in development mode, but it enables checks and gives warnings.



😊No void type tags i.e must opening and closing tag <> img,hr,br,input </>  or self closing

<img></img>
<img/>
<img></img>
 In JSX- Not Allowed <img>


*******************************************

😊You cant bind value to attribute

i.e JSX only allows property binding  -- className property
<div class="ABC XYZ PQR" id="box1">

document.getElementById('box1').className

In React

<div className="ABC PQR" id='box1'>

<label htmlFor="">




*******************************************************

# we can use both property and Attributes 

*******************************************************


# CSS and JS Integration 


CSS- style={{color:''}}
JS- {}
extrernal css- .css - import './style.css';
className="


# Media / Assets integration

media files- public - static assets
img='images/'



# 3rd Party Package Integration


**************************************************

# Assessment On React

*************************************************************

1-  Title=>Frond/backend/Fullstack=> Create Lists

Date Display like  Digital Clock
Front end
     <ol>
        <li></li>
     </ol>

   ****************************************************************  


# Task 2

     Name- Heading tag
     img-  Image
     Description
     Time-
     Date-
     

          



